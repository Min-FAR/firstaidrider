HOW TO OPEN YOUR FAR WEBSITE

1. Copy this folder to your computer.
2. Double-click the 'index.html' file.
3. Your website will open in the browser!

TO UPLOAD ONLINE (Netlify):
- Visit https://netlify.com
- Login with Google
- Click 'Add new site' > 'Deploy manually'
- Drag and drop this index.html file
- Done! Your site is live.
